package com.example.imperial_inn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
