import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/firebase_options.dart';
import 'package:imperial_inn/screens/splashScreen/splash_screen.dart';

late final FirebaseApp app;
late final FirebaseAuth auth;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  app = await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  auth = FirebaseAuth.instanceFor(app: app);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;

    // Initialize screenutil
    return ScreenUtilInit(
        designSize: Size(width, height),
        minTextAdapt: true,
        splitScreenMode: true,
        builder: (_, child) {
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Hostel Management System',
            theme: myCustomTheme,
            home: SplashScreen(),
          );
        });
  }

  // Define your custom ThemeData
  final ThemeData myCustomTheme = ThemeData(
    primaryColor: Colors.green,
    //accentColor: Colors.orange,
    fontFamily: 'Roboto', // Set your preferred font family
    textTheme: TextTheme(
      headline1: TextStyle(
          fontSize: 14.0, color: Colors.black, fontFamily: 'Lato-Bold'),
      subtitle1: TextStyle(
          fontSize: 12.0, color: Colors.black, fontFamily: 'Lato-Regular'),
    ),
  );
}
