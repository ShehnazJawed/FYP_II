class Bookings {
  String? registrationNumber;
  String? roomNumber;
  DateTime? startDate;
  DateTime? endDate;
  String? bed;
  String? totalHours;
  String? roomCharges;
  String? totalAmount;

  Bookings({
    this.registrationNumber,
    this.roomNumber,
    this.startDate,
    this.endDate,
    this.bed,
    this.totalHours,
    this.roomCharges,
    this.totalAmount,
  });

  factory Bookings.fromJson(Map<String, dynamic> json) {
    return Bookings(
      registrationNumber: json['registrationNumber'] ?? '',
      roomNumber: json['roomNumber'] ?? '',
      startDate: DateTime.parse(json['startDate']),
      endDate: DateTime.parse(json['endDate']),
      bed: json['bed'] ?? 0,
      totalHours: json['totalHours'] ?? 0,
      roomCharges: json['roomCharges'] ?? 0.0,
      totalAmount: json['totalAmount'] ?? 0.0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'registrationNumber': registrationNumber,
      'roomNumber': roomNumber,
      'startDate': startDate!.toIso8601String(),
      'endDate': endDate!.toIso8601String(),
      'bed': bed,
      'totalHours': totalHours,
      'roomCharges': roomCharges,
      'totalAmount': totalAmount,
    };
  }
}
