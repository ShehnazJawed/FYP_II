import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/screens/dashboardScreen/subScreens/aboutPageScreen.dart';
import 'package:imperial_inn/screens/dashboardScreen/subScreens/contactPageScreen.dart';
import 'package:imperial_inn/screens/dashboardScreen/subScreens/homePageScreen.dart';
import 'package:imperial_inn/utils.dart';
import 'package:imperial_inn/widgets/drawer.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => onBackPressed(),
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: primaryColor,
          title: Text('Hostel Management System', style: styleTitle),
        ),
        drawer: const DrawerWidget(userName: 'User'),
        body: _widgetOptions.elementAt(_selectedIndex),
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.info),
              label: 'About',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.contact_phone),
              label: 'Contact',
            ),
            // BottomNavigationBarItem(
            //   icon: Icon(Icons.home),
            //   label: 'Room Detail',
            // ),
          ],
          currentIndex: _selectedIndex,
          selectedItemColor: primaryColor,
          unselectedItemColor: Colors.grey.shade300,
          onTap: _onItemTapped,
        ),
      ),
    );
  }

  Future<bool> onBackPressed() async {
    // Use SystemNavigator to exit the app
    SystemNavigator.pop();
    return false; // Returning true prevents the default behavior
  }

  TextStyle styleTitle =
      TextStyle(fontSize: 18.sp, color: Colors.white, fontFamily: 'Lato-Bold');

  int _selectedIndex = 0;

  static final List<Widget> _widgetOptions = <Widget>[
    const HomePageScreen(),
    const ABoutPageScreen(),
    const ContactPageScreen(),
    //RoomDetailPageScreen()
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
}
