import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:imperial_inn/utils.dart';

class ContactPageScreen extends StatefulWidget {
  const ContactPageScreen({super.key});

  @override
  State<ContactPageScreen> createState() => _ContactPageScreenState();
}

class _ContactPageScreenState extends State<ContactPageScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: ListView(shrinkWrap: true, children: [
            Container(
              height: 260.h, // Container height
              child: GoogleMap(
                onMapCreated: (GoogleMapController controller) {
                  mapController = controller;
                },
                initialCameraPosition: CameraPosition(
                  target: _center,
                  zoom: 12.0,
                ),
                markers: {
                  Marker(
                    markerId: MarkerId('hyderabad_sindh'),
                    position: _center,
                    infoWindow: InfoWindow(
                      title: 'Hyderabad, Sindh',
                    ),
                  ),
                },
              ),
            ),
            SizedBox(
              height: 20.h,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'CONTACT US',
                  style: styleHeading,
                ),
                SizedBox(
                  height: 10.h,
                ),
                RichText(
                  text: TextSpan(
                      text: 'CONTACT ',
                      style: styleHeadingB,
                      children: <TextSpan>[
                        TextSpan(
                          text: "For Any Query",
                          style: styleHeadingP,
                        )
                      ]),
                ),
                SizedBox(
                  height: 60.h,
                ),
                ListTile(
                  title: Text(
                    textAlign: TextAlign.justify,
                    'Imperial Inn Hotel- is situated in a very expensive area of Hyderabad, Pakistan, Near Autobahn Road.',
                    style: styletile,
                  ),
                  leading: Icon(Icons.location_on_rounded, color: primaryColor),
                ),
                ListTile(
                  title: Text(
                    'admin@imperialinnhotel.com',
                    style: styletile,
                  ),
                  leading: Icon(Icons.email_outlined, color: primaryColor),
                ),
                ListTile(
                  title: Text(
                    '+92 348 5999994',
                    style: styletile,
                  ),
                  leading: Icon(Icons.phone, color: primaryColor),
                ),
              ],
            ),
          ])),
    );
  }

  GoogleMapController? mapController;

  final LatLng _center =
      const LatLng(25.3924, 68.3737); // Hyderabad, Sindh, Pakistan

  TextStyle styleHeading =
      TextStyle(fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingP =
      TextStyle(fontSize: 22.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingB =
      TextStyle(fontSize: 20.sp, color: Colors.black, fontFamily: 'Lato-Bold');
  TextStyle styletile = TextStyle(
      fontSize: 16.sp, color: Colors.black, fontFamily: 'Lato-Regular');
}
