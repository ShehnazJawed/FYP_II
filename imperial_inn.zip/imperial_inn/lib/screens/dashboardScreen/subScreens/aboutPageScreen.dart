import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/utils.dart';

class ABoutPageScreen extends StatefulWidget {
  const ABoutPageScreen({super.key});

  @override
  State<ABoutPageScreen> createState() => _ABoutPageScreenState();
}

class _ABoutPageScreenState extends State<ABoutPageScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView(
          shrinkWrap: true,
          //crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.only(top: 5),
              child: CarouselSlider(
                options: CarouselOptions(
                  height: 250.h,
                  aspectRatio: 16 / 9,
                  viewportFraction: 1,
                  autoPlay: true,
                  autoPlayInterval: Duration(seconds: 3),
                  autoPlayAnimationDuration: Duration(milliseconds: 800),
                  autoPlayCurve: Curves.fastOutSlowIn,
                  pauseAutoPlayOnTouch: true,
                  enableInfiniteScroll: true,
                  scrollDirection: Axis.horizontal,
                  onPageChanged: (index, reason) {
                    setState(() {
                      _current = index; // Update _current when the page changes
                    });
                  },
                ),
                items: images.map((image) {
                  return Builder(
                    builder: (BuildContext context) {
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.symmetric(horizontal: 5.0),
                        decoration: BoxDecoration(
                          color: Colors.grey,
                        ),
                        child: Image.asset(
                          image,
                          fit: BoxFit.cover,
                        ),
                      );
                    },
                  );
                }).toList(),
              ),
            ),
            _buildIndicator(images.length),
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    'ABOUT US',
                    style: styleHeading,
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  RichText(
                    text: TextSpan(
                        text: 'Welcome to ',
                        style: styleHeadingB,
                        children: <TextSpan>[
                          TextSpan(
                            text: "IMPERIAL INN",
                            style: styleHeadingP,
                          )
                        ]),
                  ),
                  SizedBox(
                    height: 10.h,
                  ),
                  Text(
                    """Welcome to Imperial Inn Hostel, where comfort meets affordability in the heart of the city. Our Hotels offers a warm and inviting atmosphere, providing travelers with a budget friendly yet stylish accommodation option. Whether you're a student or professional With friends, our well-appointed rooms and communal spaces are designed to make your stay enjoyable. Immerse yourself in the vibrant local culture, explore nearby attractions, and return to the cozy embrace of Imperial Inn for a restful night's sleep. Our friendly staff is always ready to assist you, ensureing a memorable and hassle-free experience during your visit. Welcome to your home away from home at Imperial Inn Hostel, where every one is a valued guest
                    """,
                    textAlign: TextAlign.justify,
                    style: styleDes,
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  int _current = 0; // Initialize _current to keep track of the current index

  final List<String> images = [
    'assets/images/image1.jpg',
    'assets/images/image2.jpg',
    'assets/images/image3.jpg',
    'assets/images/image4.jpg',
    'assets/images/image5.jpg',
  ];
  TextStyle styleHeading =
      TextStyle(fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleDes = TextStyle(
      fontSize: 15.sp, color: Colors.black, fontFamily: 'Lato-Regular');
  TextStyle styleHeadingP =
      TextStyle(fontSize: 22.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingB =
      TextStyle(fontSize: 20.sp, color: Colors.black, fontFamily: 'Lato-Bold');
  Widget _buildIndicator(int itemCount) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        itemCount,
        (index) => Container(
          width: 8,
          height: 8,
          margin: EdgeInsets.symmetric(vertical: 10, horizontal: 2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.blue.withOpacity(index == _current ? 0.9 : 0.4),
          ),
        ),
      ),
    );
  }
}
