// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';

// import 'package:imperial_inn/scale_size.dart';
// import 'package:imperial_inn/utils.dart';

// class RoomDetailPageScreen extends StatefulWidget {

//   @override
//   State<RoomDetailPageScreen> createState() => _RoomDetailPageScreenState();
// }

// class _RoomDetailPageScreenState extends State<RoomDetailPageScreen> {
//   TextEditingController _registrationController = TextEditingController();
//   TextEditingController _roomNoController = TextEditingController();
//   TextEditingController _startDateController = TextEditingController();
//   TextEditingController _endDateController = TextEditingController();
//   TextEditingController _hoursController = TextEditingController();
//   TextEditingController _chargesController = TextEditingController();
//   TextEditingController _amountController = TextEditingController();
//   TextEditingController _bedController = TextEditingController();

//   TextStyle styleButton =
//       TextStyle(fontSize: 16.sp, color: Colors.white, fontFamily: 'Lato-Bold');
//   TextStyle styleHeading =
//       TextStyle(fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Bold');
//   TextStyle styleHeadingRegisterBtn =
//       TextStyle(fontSize: 16.sp, color: Colors.red, fontFamily: 'Lato-Bold');
//   TextStyle styleTitle =
//       TextStyle(fontSize: 18.sp, color: Colors.white, fontFamily: 'Lato-Bold');

//   @override
//   Widget build(BuildContext context) {
//     // _registrationController.text = widget.data.registrationNumber!;
//     // _roomNoController.text = widget.data.roomNumber!;
//     // _startDateController.text = "${widget.data.startDate}";
//     // _endDateController.text = "${widget.data.endDate}";
//     // _bedController.text = widget.data.bed!;
//     // _hoursController.text = widget.data.totalHours!;
//     // _chargesController.text = widget.data.roomCharges!;
//     // _amountController.text = widget.data.totalAmount!;
//     return GestureDetector(
//         onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
//         child: Scaffold(
//           body: Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: SingleChildScrollView(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 children: [
//                   SizedBox(
//                     height: 10.h,
//                   ),
//                   Card(
//                     elevation: 2,
//                     child: Padding(
//                       padding: EdgeInsets.all(10),
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: [
//                           //Registration Number
//                           Text(
//                             'Registration Number',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             readOnly: true,
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _registrationController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.money_rounded,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),

//                           SizedBox(height: 10.h),
//                           //Room Number
//                           Text(
//                             'Room Number',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             readOnly: true,
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _roomNoController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.money_rounded,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),
//                           SizedBox(height: 10.h),
//                           //Start Date
//                           Text(
//                             'Start Date',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             readOnly: true,
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _startDateController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.money_rounded,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),
//                           SizedBox(height: 10.h),
//                           //End Date
//                           Text(
//                             'End Date',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             readOnly: true,
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _bedController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.money_rounded,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),
//                           SizedBox(height: 10.h),
//                           //Bed No
//                           Text(
//                             'Bed',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             readOnly: true,
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _bedController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.money_rounded,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),
//                           SizedBox(height: 10.h),
//                           //Total Hours
//                           Text(
//                             'Total Hours',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _hoursController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.numbers_outlined,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),
//                           SizedBox(height: 10.h),
//                           //City Name
//                           Text(
//                             'Room Charges',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             readOnly: true,
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _chargesController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.money_rounded,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),
//                           SizedBox(height: 10.h),
//                           //Country Name
//                           Text(
//                             'Total Amount',
//                             style: styleHeading,
//                             textScaleFactor: ScaleSize.textScaleFactor(context),
//                           ),
//                           SizedBox(height: 5.h),
//                           TextField(
//                             readOnly: true,
//                             style: Theme.of(context).textTheme.subtitle1,
//                             cursorColor: primaryColor,
//                             controller: _amountController,
//                             decoration: InputDecoration(
//                               prefixIcon: Icon(
//                                 Icons.money_off_csred_rounded,
//                                 color: primaryColor,
//                               ),
//                               focusedBorder: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12),
//                                   borderSide: BorderSide(color: primaryColor)),
//                               border: OutlineInputBorder(
//                                   borderRadius: BorderRadius.circular(12)),
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ));
//   }
// }
