import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/screens/roomBookScreen/roomBookScreen.dart';
import 'package:imperial_inn/utils.dart';

class HomePageScreen extends StatefulWidget {
  const HomePageScreen({super.key});

  @override
  State<HomePageScreen> createState() => _HomePageScreenState();
}

class _HomePageScreenState extends State<HomePageScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        //shrinkWrap: true,
        children: [
          Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 20.h,
                ),
                Text(
                  'OUR ROOMS',
                  style: styleHeading,
                ),
                SizedBox(
                  height: 10.h,
                ),
                RichText(
                  text: TextSpan(
                      text: 'Explore Our',
                      style: styleHeadingB,
                      children: <TextSpan>[
                        TextSpan(
                          text: "ROOMS",
                          style: styleHeadingP,
                        )
                      ]),
                ),
                SizedBox(
                  height: 30.h,
                ),
              ],
            ),
          ),
          Expanded(
            flex: 4,
            //height: 300.h,
            child: ListView.builder(
                itemCount: myData.length,
                itemBuilder: (context, index) {
                  return customShow(
                      '${myData[index]['image']}',
                      '${myData[index]['price']}',
                      '${myData[index]['roomType']}',
                      '${myData[index]['bed']}',
                      '${myData[index]['des']}', () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (_) => RoomBookScreen(
                              price: '${myData[index]['price']}',
                              bed: '${myData[index]['bed']}',
                              roomType: '${myData[index]['roomType']}',
                            )));
                  });
                }),
          )
        ],
      ),
    );
  }

  TextStyle styleHeading =
      TextStyle(fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeading2 =
      TextStyle(fontSize: 16.sp, color: Colors.black, fontFamily: 'Lato-Bold');
  TextStyle styleHeading2R = TextStyle(
      fontSize: 16.sp, color: Colors.black, fontFamily: 'Lato-Regular');
  TextStyle styleHeading3 =
      TextStyle(fontSize: 16.sp, color: Colors.white, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingP =
      TextStyle(fontSize: 22.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingB =
      TextStyle(fontSize: 20.sp, color: Colors.black, fontFamily: 'Lato-Bold');

  List<Map<String, dynamic>> myData = [
    {
      'image': 'assets/images/singlebed.jpg',
      'price': '500',
      'roomType': 'Single Bed',
      'bed': '1',
      'des':
          'Single bed room with multiple facilities wifi, Non-AC, Generator and with 1 bath.',
    },
    {
      'image': 'assets/images/room6.jpg',
      'price': '1000',
      'roomType': 'Twin Bedroom',
      'bed': '2',
      'des':
          'Twin bed room with multiple facilities wifi, Non-AC, Generator and with 1 bath.',
    },
    {
      'image': 'assets/images/Bunker_img.jpg',
      'price': '700',
      'roomType': 'Bunker Bedroom',
      'bed': '2',
      'des':
          'Bunker bed Capacity in one room every single bed with facilities wifi, AC, Generator.',
    },
    {
      'image': 'assets/images/twinbed2.jpg',
      'price': '1500',
      'roomType': 'Twin Bed',
      'bed': '2',
      'des':
          'Twin bed room with facilities wifi, AC,LED, Generator and with 1 bath.',
    },
    {
      'image': 'assets/images/twinbed.jpg',
      'price': '2000',
      'roomType': 'Twin Bed',
      'bed': '2',
      'des':
          'Twin bed room with facilities wifi, AC,LED,2 time meal, Generator and with 1 bath and kitchen.',
    },
    {
      'image': 'assets/images/singlebed2.jpg',
      'price': '2500',
      'roomType': 'Single Bed',
      'bed': '1',
      'des':
          'single bed room with multiple facilities wifi,AC,LED,3 time meal, Generator and with 1 bath,kitchen and study area.',
    }
  ];

  customShow(String img, String price, String roomType, String bed, String des,
      VoidCallback onTap) {
    return Card(
      child: Column(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              Container(
                height: 200.h,
                width: double.infinity,
                child: Image.asset(
                  '$img',
                  fit: BoxFit.cover,
                ),
              ),
              Positioned(
                left: 80,
                top: 185,
                child: Container(
                  padding: EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey, width: 1.0),
                    borderRadius: BorderRadius.circular(8.0),
                    color: primaryColor,
                  ),
                  child: Text(
                    'Pkr $price/Night',
                    style: styleHeading3,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 40.h,
          ),
          Container(
            child: Padding(
              padding: const EdgeInsets.only(left: 12, right: 12),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '$roomType',
                      style: styleHeading2,
                    ),
                    Container(
                      child: Row(children: [
                        Icon(
                          Icons.star,
                          color: primaryColor,
                        ),
                        Icon(
                          Icons.star,
                          color: primaryColor,
                        ),
                        Icon(
                          Icons.star,
                          color: primaryColor,
                        ),
                        Icon(
                          Icons.star,
                          color: primaryColor,
                        ),
                        Icon(
                          Icons.star,
                          color: primaryColor,
                        ),
                      ]),
                    )
                  ]),
            ),
          ),
          SizedBox(
            height: 20.h,
          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Row(
                  children: [
                    Icon(Icons.bed_outlined, color: primaryColor),
                    SizedBox(
                      width: 5.w,
                    ),
                    Text('$bed Bed', style: styleHeading2R),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.bathroom_outlined, color: primaryColor),
                    SizedBox(
                      width: 5.w,
                    ),
                    Text('1 Bath', style: styleHeading2R),
                  ],
                ),
                Row(
                  children: [
                    Icon(
                      Icons.wifi,
                      color: primaryColor,
                    ),
                    SizedBox(
                      width: 5.w,
                    ),
                    Text(
                      'Wifi',
                      style: styleHeading2R,
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              '$des',
              style: styleHeading2R,
            ),
          ),
          SizedBox(
            height: 20.h,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                width: 40.w,
              ),
              GestureDetector(
                onTap: onTap,
                child: Container(
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey, width: 1.0),
                    borderRadius: BorderRadius.circular(8.0),
                    color: primaryColor,
                  ),
                  child: Text(
                    'Book Now',
                    style: styleHeading3,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 20.h,
          ),
        ],
      ),
    );
  }
}
