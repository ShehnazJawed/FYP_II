import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/main.dart';
import 'package:imperial_inn/screens/dashboardScreen/dashBoardScreen.dart';
import 'package:imperial_inn/screens/loginScreen/loginScreen.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Add a delay of 5 seconds before navigating to the home screen
    Future.delayed(Duration(seconds: 3), () {
      checkLoginStatus();
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
              builder: (_) => StreamBuilder<User?>(
                    stream: auth.authStateChanges(),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        return DashboardScreen();
                      }
                      return LoginScreen();
                    },
                  )),
          (route) => false);
    });
  }

  void checkLoginStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;

    if (isLoggedIn) {
      // Navigate to appropriate screen based on user type
      bool isLoggedIn = prefs.getBool('isLoggedIn') ?? false;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
            builder: (context) =>
                isLoggedIn ? DashboardScreen() : LoginScreen()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Center(
          child: Container(
            height: 300.h,
            width: double.infinity,
            decoration: const BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/images/logo.jpg'))),
          ),
        ),
      ),
    );
  }
}
