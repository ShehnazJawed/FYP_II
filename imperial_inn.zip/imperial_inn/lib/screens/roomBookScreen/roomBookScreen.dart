import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/models/roomBookModel.dart';
import 'package:imperial_inn/scale_size.dart';
import 'package:imperial_inn/screens/dashboardScreen/dashBoardScreen.dart';
import 'package:imperial_inn/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RoomBookScreen extends StatefulWidget {
  final String price;
  final String bed;
  final String roomType;

  const RoomBookScreen(
      {super.key,
      required this.price,
      required this.bed,
      required this.roomType});

  @override
  State<RoomBookScreen> createState() => _RoomBookScreenState();
}

class _RoomBookScreenState extends State<RoomBookScreen> {
  @override
  Widget build(BuildContext context) {
    setState(() {
      _roomTypeController.text = 'Your roomType is ${widget.roomType}';
      _bedController.text = 'You have ${widget.bed} Bed';
      _chargesController.text = 'Your Total Charges $charges';
      _amountController.text = 'Total Amount Here: $charges';
    });

    return GestureDetector(
        onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
        child: Scaffold(
          appBar: AppBar(
              leading: IconButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  icon: const Icon(
                    Icons.arrow_back_outlined,
                    color: Colors.white,
                  )),
              backgroundColor: primaryColor,
              title: Text('Hostel Bookings', style: styleTitle)),
          body: Padding(
            padding: const EdgeInsets.all(8.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 10.h,
                  ),
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Facilities',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),

                          Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                CheckboxListTile(
                                  title: Text(
                                    'Breakfast - 200 PKR',
                                    style: styleFacilities,
                                  ),
                                  value: checkboxBreakfast,
                                  onChanged: (newValue) {
                                    setState(() {
                                      checkboxBreakfast = newValue!;
                                    });
                                  },
                                ),
                                CheckboxListTile(
                                  title: Text(
                                    'Lunch - 100 PKR',
                                    style: styleFacilities,
                                  ),
                                  value: checkboxLunch,
                                  onChanged: (newValue) {
                                    setState(() {
                                      checkboxLunch = newValue!;
                                    });
                                  },
                                ),
                                CheckboxListTile(
                                  title: Text(
                                    'Dinner - 200 PKR',
                                    style: styleFacilities,
                                  ),
                                  value: checkboxDinner,
                                  onChanged: (newValue) {
                                    setState(() {
                                      checkboxDinner = newValue!;
                                    });
                                  },
                                ),
                                CheckboxListTile(
                                  title: Text(
                                    'Room Cleaning- 100 PKR',
                                    style: styleFacilities,
                                  ),
                                  value: checkboxRoomClean,
                                  onChanged: (newValue) {
                                    setState(() {
                                      checkboxRoomClean = newValue!;
                                    });
                                  },
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 10.h),
                          //Registration Number
                          Text(
                            'Registration Number',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          TextField(
                            readOnly: true,
                            style: Theme.of(context).textTheme.subtitle1,
                            cursorColor: primaryColor,
                            controller: _registrationNumController,
                            decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.money_rounded,
                                color: primaryColor,
                              ),
                              hintText: '000',
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: primaryColor)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),

                          SizedBox(height: 10.h),

                          //Room Number
                          Text(
                            'Room Type',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          TextField(
                            readOnly: true,
                            style: Theme.of(context).textTheme.subtitle1,
                            cursorColor: primaryColor,
                            controller: _roomTypeController,
                            decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.money_rounded,
                                color: primaryColor,
                              ),
                              hintText: 'You have ${widget.bed} Bed',
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: primaryColor)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                          SizedBox(height: 10.h),

                          //Start Date
                          Text(
                            'Start Date',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          GestureDetector(
                            onTap: () {
                              _showStartDatePicker(context);
                            },
                            child: Container(
                              height: 60.h,
                              padding: const EdgeInsets.only(left: 8, right: 8),
                              decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.grey, width: 1.0),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    '${_startDate.toString().split(' ')[0]}',
                                    style:
                                        Theme.of(context).textTheme.subtitle1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 10.h),
                          //Gender

                          //End Date
                          Text(
                            'End Date',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          GestureDetector(
                            onTap: () {
                              _showEndDatePicker(context);
                            },
                            child: Container(
                              height: 60.h,
                              padding: const EdgeInsets.only(left: 8, right: 8),
                              decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.grey, width: 1.0),
                                borderRadius: BorderRadius.circular(8.0),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    '${_endDate.toString().split(' ')[0]}',
                                    style:
                                        Theme.of(context).textTheme.subtitle1,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          SizedBox(height: 10.h),

                          //Bed No
                          Text(
                            'Bed',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          TextField(
                            readOnly: true,
                            style: Theme.of(context).textTheme.subtitle1,
                            cursorColor: primaryColor,
                            controller: _bedController,
                            decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.money_rounded,
                                color: primaryColor,
                              ),
                              //hintText: 'You have ${widget.bed} Bed',
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: primaryColor)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                          SizedBox(height: 10.h),
                          //City Name
                          Text(
                            'Room Charges',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          TextField(
                            readOnly: true,
                            style: Theme.of(context).textTheme.subtitle1,
                            cursorColor: primaryColor,
                            controller: _chargesController,
                            decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.money_rounded,
                                color: primaryColor,
                              ),
                              hintText: 'Your Total Charges ',
                              //labelText: 'Username',
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: primaryColor)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                          SizedBox(height: 10.h),
                          //Country Name
                          Text(
                            'Total Amount',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          TextField(
                            readOnly: true,
                            style: Theme.of(context).textTheme.subtitle1,
                            cursorColor: primaryColor,
                            controller: _amountController,
                            decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.money_off_csred_rounded,
                                color: primaryColor,
                              ),
                              hintText: 'Total Amount Here: ',
                              //labelText: 'Username',
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: primaryColor)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                          SizedBox(height: 10.h),
                          Text(
                            _errorMessage,
                            style: const TextStyle(color: Colors.red),
                          ),
                          SizedBox(height: 30.h),
                          GestureDetector(
                            onTap: signUpUser,
                            child: Container(
                              padding: const EdgeInsets.all(12),
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: primaryColor,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Center(
                                  child: Text(
                                'Book Room',
                                style: styleButton,
                              )),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  }

  final CollectionReference bookRoom =
      FirebaseFirestore.instance.collection('bookRoom');

  String _errorMessage = '';

  Future signUpUser() async {
    //create user
    if (_validateFields()) {
      // Create user in Firebase Authentication
      try {
        // Add user details to Firestore
        await addRoomDetail(
            checkboxBreakfast,
            checkboxLunch,
            checkboxDinner,
            checkboxRoomClean,
            int.parse(_registrationNumController.text.trim()),
            _roomTypeController.text.trim(),
            _startDate,
            _endDate,
            _bedController.text.trim(),
            _chargesController.text.trim(),
            _amountController.text.trim());

        // Navigate to DashboardScreen
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => DashboardScreen()),
            (route) => false);
        setState(() {
          snackBar('Succesfully Book');
        });
      } catch (e) {
        print('Error signing up: $e');
        setState(() {
          _errorMessage = '$e';
        });
        // Handle error gracefully and provide feedback to the user
      }
    } else {
      // Show error message for empty fields
      setState(() {
        _errorMessage = 'Error: Fields cannot be empty';
      });
      // You can set an error message state variable and display it to the user
    }
  }

  Future addRoomDetail(
    bool breakFast,
    bool lunch,
    bool dinner,
    bool roomClean,
    int regiNumb,
    String roomT,
    DateTime dateStart,
    DateTime dateEnd,
    String bed,
    String roomCharges,
    String amountTotal,
  ) async {
    await bookRoom.add({
      'breakFast': breakFast,
      'lunch': lunch,
      'dinner': dinner,
      'roomClean': roomClean,
      'regiNumb': regiNumb,
      'roomT': roomT,
      'dateStart': dateStart,
      'dateEnd': dateEnd,
      'bed': bed,
      'roomCharges': roomCharges,
      'amountTotal': amountTotal,
      //'timestamp': Timestamp.now(),
    });
  }

  bool _validateFields() {
    return
        // checkboxBreakfast != null &&
        //     checkboxLunch != null &&
        //     checkboxDinner != null &&
        //     checkboxRoomClean != null &&
        _registrationNumController.text.isNotEmpty &&
            _roomTypeController.text.isNotEmpty &&
            _startDate != null &&
            _endDate != null &&
            _bedController.text.isNotEmpty &&
            _chargesController.text.isNotEmpty &&
            _amountController.text.isNotEmpty;
  }

  Future<void> _showStartDatePicker(BuildContext context) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (pickedDate != null && pickedDate != _startDate) {
      setState(() {
        _startDate = pickedDate;
      });
    }
  }

  Future<void> _showEndDatePicker(BuildContext context) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: _endDate,
      firstDate: _startDate,
      lastDate: DateTime(2100),
    );

    if (pickedDate != null && pickedDate != _endDate) {
      setState(() {
        _endDate = pickedDate;
        _calculateSelectedDays();
      });
    }
  }

  int charges = 0;

  String _calculateSelectedDays() {
    final difference = _endDate.difference(_startDate).inDays;
    setState(() {
      final value = int.parse(widget.price);
      final price = difference * value;
      charges = price;
    });
    return difference.toString();
  }

  @override
  void initState() {
    super.initState();
    _loadRegistrationNumber();
    _startDate = DateTime.now();
    _endDate = DateTime.now().add(
        const Duration(days: 7)); // Initial end date is 7 days after start date
  }

  bool checkboxBreakfast = false;
  bool checkboxLunch = false;
  bool checkboxDinner = false;
  bool checkboxRoomClean = false;
  final TextEditingController _registrationNumController =
      TextEditingController();
  final TextEditingController _roomTypeController = TextEditingController();
  late DateTime _startDate;
  late DateTime _endDate;
  final TextEditingController _bedController = TextEditingController();
  final TextEditingController _chargesController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();

  String? registerationNumber;
  String? roomNumber;
  String? selectRoom;

  TextStyle styleButton =
      TextStyle(fontSize: 16.sp, color: Colors.white, fontFamily: 'Lato-Bold');
  TextStyle styleHeading =
      TextStyle(fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleFacilities = TextStyle(
      fontSize: 16.sp, color: Colors.black, fontFamily: 'Lato-Regular');
  TextStyle styleTitle =
      TextStyle(fontSize: 18.sp, color: Colors.white, fontFamily: 'Lato-Bold');

  Future<void> _loadRegistrationNumber() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? registrationNumber = prefs.getString('registrationNumber');
    if (registrationNumber != null) {
      setState(() {
        _registrationNumController.text = registrationNumber;
      });
    }
  }
}
