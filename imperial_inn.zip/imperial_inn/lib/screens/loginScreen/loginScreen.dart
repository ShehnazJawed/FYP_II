import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/scale_size.dart';
import 'package:imperial_inn/screens/dashboardScreen/dashBoardScreen.dart';
import 'package:imperial_inn/screens/registerScreen/registerScreen.dart';
import 'package:imperial_inn/utils.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: SafeArea(
        child: Scaffold(
          body: Padding(
            padding: EdgeInsets.all(8.0),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                      child: Center(
                          child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        height: 30.h,
                      ),
                      Container(
                        height: 300.h,
                        width: double.infinity,
                        decoration: const BoxDecoration(
                            image: DecorationImage(
                                image: AssetImage('assets/images/logo.jpg'))),
                      ),
                      Text('User Login', style: styleHeadingLogin),
                    ],
                  ))),
                  SizedBox(
                    height: 30.h,
                  ),
                  Card(
                    elevation: 2,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Email',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          TextField(
                            style: Theme.of(context).textTheme.subtitle1,
                            cursorColor: primaryColor,
                            controller: _usernameController,
                            decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.person_outline,
                                color: primaryColor,
                              ),
                              hintText: 'Enter your Email',
                              //labelText: 'Username',
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: primaryColor)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                          SizedBox(height: 10.h),
                          Text(
                            'Password',
                            style: styleHeading,
                            textScaleFactor: ScaleSize.textScaleFactor(context),
                          ),
                          SizedBox(height: 5.h),
                          TextField(
                            style: Theme.of(context).textTheme.subtitle1,
                            cursorColor: primaryColor,
                            controller: _passwordController,
                            obscureText: true,
                            decoration: InputDecoration(
                              prefixIcon: Icon(
                                Icons.lock_outline,
                                color: primaryColor,
                              ),
                              //labelText: 'Password',
                              hintText: 'Enter your Password',
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  borderSide: BorderSide(color: primaryColor)),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                          ),
                          SizedBox(height: 10.h),
                          Text(
                            _errorMessage,
                            style: const TextStyle(color: Colors.red),
                          ),
                          SizedBox(height: 10.h),
                          GestureDetector(
                            onTap: loginUser,
                            child: Container(
                              padding: EdgeInsets.all(12),
                              width: double.infinity,
                              decoration: BoxDecoration(
                                color: primaryColor,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Center(
                                  child: Text(
                                'Login',
                                style: styleButton,
                              )),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    child: Center(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          SizedBox(
                            height: 30.h,
                          ),
                          TextButton(
                              onPressed: () {
                                Navigator.of(context).push(MaterialPageRoute(
                                    builder: (_) => RegisterScreen()));
                              },
                              child: Text('Register Now',
                                  style: styleHeadingRegisterBtn))
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
  }

  Future<void> loginUser() async {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter both username and password.';
      });
    } else {
      try {
        UserCredential userCredential =
            await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: username,
          password: password,
        );
        print('print check ${userCredential.user}');
        // If userCredential is not null, the login was successful
        if (userCredential.user != null) {
          // Navigate to DashboardScreen upon successful login
          Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => const DashboardScreen()));
          setState(() {
            snackBar('Succesfully Login');
          });
        } else {
          setState(() {
            _errorMessage = 'Invalid username or password.';
          });
        }
      } catch (e) {
        print('Error logging in: $e');
        setState(() {
          // _errorMessage = 'Error logging in. Please try again later.';
          _errorMessage = 'Invalid username or password.';
        });
      }
    }
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  TextStyle styleButton =
      TextStyle(fontSize: 16.sp, color: Colors.white, fontFamily: 'Lato-Bold');
  TextStyle styleHeading =
      TextStyle(fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingLogin =
      TextStyle(fontSize: 22.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingRegisterBtn =
      TextStyle(fontSize: 16.sp, color: Colors.red, fontFamily: 'Lato-Bold');
}
