import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/scale_size.dart';
import 'package:imperial_inn/screens/dashboardScreen/dashBoardScreen.dart';
import 'package:imperial_inn/screens/loginScreen/loginScreen.dart';
import 'package:imperial_inn/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  child: Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SizedBox(
                          height: 40.h,
                        ),
                        Text('Registration Form', style: styleHeadingLogin),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 30.h,
                ),
                Card(
                  elevation: 2,
                  child: Padding(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        //Registration Number
                        Text(
                          'Registration Number',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          readOnly: true,
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          keyboardType: TextInputType.number,
                          controller: _registrationNumController,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.numbers_outlined,
                              color: primaryColor,
                            ),
                            hintText: 'Enter Registration Number Here',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //FirstName
                        Text(
                          'First Name',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _firstNameController,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.person_outline,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your First Name',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Fathername
                        Text(
                          'Father Name',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _fNameController,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.person_outline,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your Father Name',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Gender
                        Text(
                          'Gender',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        Container(
                          height: 60.h,
                          padding: const EdgeInsets.only(left: 8, right: 8),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey, width: 1.0),
                            borderRadius: BorderRadius.circular(8.0),
                          ),
                          child: DropdownButton<String>(
                            style: Theme.of(context).textTheme.subtitle1,
                            isExpanded: true,
                            value: gender,
                            underline: const SizedBox(),
                            onChanged: (String? newValue) {
                              setState(() {
                                gender = newValue!;
                              });
                            },
                            hint: const Text('Gender'),
                            items: <String>[
                              'Male',
                              'Female',
                              'Rather Not Say',
                            ].map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Contact Number
                        Text(
                          'Contact Number',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _contactNumController,
                          maxLength: 11,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.phone_outlined,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your Contact Number',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Emergency Contact No
                        Text(
                          'Emergency Contact Number',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _emergencyContactNumController,
                          maxLength: 11,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.phone_outlined,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your Emergency Contact Number',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Email Id
                        Text(
                          'Email ID',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          keyboardType: TextInputType.emailAddress,
                          controller: _usernameController,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.email_outlined,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your Email',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Password
                        Text(
                          'Password',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _passwordController,
                          obscureText: true,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.lock_outline,
                              color: primaryColor,
                            ),
                            //labelText: 'Password',
                            hintText: 'Enter your Password',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Confrim Password
                        Text(
                          'Confrim Password',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _confrimPasswordController,
                          obscureText: true,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.lock_outline,
                              color: primaryColor,
                            ),
                            //labelText: 'Password',
                            hintText: 'Enter your Confrim Password',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //City Name
                        Text(
                          'City Name',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _cityNameController,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.location_city_outlined,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your City Name',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        //Country Name
                        Text(
                          'Country Name',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          controller: _countryNameController,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.location_on_rounded,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your Country Name',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),

                        //CNIC Number
                        Text(
                          'CNIC Number',
                          style: styleHeading,
                          textScaleFactor: ScaleSize.textScaleFactor(context),
                        ),
                        SizedBox(height: 5.h),
                        TextField(
                          style: Theme.of(context).textTheme.subtitle1,
                          cursorColor: primaryColor,
                          maxLength: 13,
                          keyboardType: TextInputType.number,
                          controller: _CNICNumController,
                          decoration: InputDecoration(
                            prefixIcon: Icon(
                              Icons.numbers_outlined,
                              color: primaryColor,
                            ),
                            hintText: 'Enter your CNIC Number',
                            //labelText: 'Username',
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(color: primaryColor)),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        SizedBox(height: 10.h),
                        Text(
                          _errorMessage,
                          style: TextStyle(color: Colors.red),
                        ),
                        SizedBox(height: 10.h),

                        GestureDetector(
                          onTap: signUpUser,
                          child: Container(
                            padding: EdgeInsets.all(12),
                            width: double.infinity,
                            decoration: BoxDecoration(
                              color: primaryColor,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: Text(
                                'Register',
                                style: styleButton,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                  child: Center(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        SizedBox(
                          height: 30.h,
                        ),
                        TextButton(
                            onPressed: () {
                              Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) => LoginScreen()));
                            },
                            child: Text('already have account',
                                style: styleHeadingRegisterBtn)),
                        SizedBox(
                          height: 20.h,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  final TextEditingController _registrationNumController =
      TextEditingController();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _fNameController = TextEditingController();
  String? gender;
  final TextEditingController _contactNumController = TextEditingController();
  final TextEditingController _emergencyContactNumController =
      TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confrimPasswordController =
      TextEditingController();
  final TextEditingController _cityNameController = TextEditingController();
  final TextEditingController _countryNameController = TextEditingController();
  final TextEditingController _CNICNumController = TextEditingController();
  String _errorMessage = '';

  TextStyle styleButton =
      TextStyle(fontSize: 16.sp, color: Colors.white, fontFamily: 'Lato-Bold');
  TextStyle styleHeading =
      TextStyle(fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingLogin =
      TextStyle(fontSize: 22.sp, color: primaryColor, fontFamily: 'Lato-Bold');
  TextStyle styleHeadingRegisterBtn =
      TextStyle(fontSize: 16.sp, color: Colors.red, fontFamily: 'Lato-Bold');

  final CollectionReference details =
      FirebaseFirestore.instance.collection('user');

  Future signUpUser() async {
    //create user
    if (_validateFields() && confrimPass()) {
      // Create user in Firebase Authentication
      try {
        await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: _usernameController.text.trim(),
          password: _passwordController.text.trim(),
        );
        // Add user details to Firestore
        await addUserDetail(
            _registrationNumController.text.trim(),
            _firstNameController.text.trim(),
            _fNameController.text.trim(),
            gender!,
            _contactNumController.text.trim(),
            _emergencyContactNumController.text.trim(),
            _usernameController.text.trim(),
            _cityNameController.text.trim(),
            _countryNameController.text.trim(),
            int.parse(_CNICNumController.text.trim()));
        _storeRegistrationNumber();
        // Navigate to DashboardScreen
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => DashboardScreen()),
            (route) => false);
        setState(() {
          snackBar('Succesfully Login');
        });
      } catch (e) {
        print('Error signing up: $e');
        setState(() {
          _errorMessage = '$e';
        });
        // Handle error gracefully and provide feedback to the user
      }
    } else {
      // Show error message for empty fields
      setState(() {
        _errorMessage = 'Error: Fields cannot be empty';
      });
      // You can set an error message state variable and display it to the user
    }
  }

  Future addUserDetail(
      String regNo,
      String firstName,
      String fName,
      String gender,
      String contactNo,
      String emContactNo,
      String email,
      String cityName,
      String countryName,
      int CNIC_No) async {
    await details.add({
      'registrationNo': regNo,
      'firstName': firstName,
      'fatherName': fName,
      'gender': gender,
      'contact': contactNo,
      'emergencyContact': emContactNo,
      'email': email,
      'cityName': cityName,
      'countryName': countryName,
      'CNIC_No': CNIC_No
      //'timestamp': Timestamp.now(),
    });
  }

  bool _validateFields() {
    return _registrationNumController.text.isNotEmpty &&
        _firstNameController.text.isNotEmpty &&
        _fNameController.text.isNotEmpty &&
        gender != null &&
        _contactNumController.text.isNotEmpty &&
        _emergencyContactNumController.text.isNotEmpty &&
        _usernameController.text.isNotEmpty &&
        _cityNameController.text.isNotEmpty &&
        _countryNameController.text.isNotEmpty &&
        _CNICNumController.text.isNotEmpty;
  }

  bool confrimPass() {
    if (_passwordController.text == _confrimPasswordController.text) {
      return true;
    } else {
      return false;
    }
  }

  String generateRegistrationNumber() {
    // Generate a random number for the registration number
    Random random = Random();
    int randomNumber = random.nextInt(900) + 100; // Generate a 6-digit number

    // Customize the registration number format as per your requirements
    String registrationNumber =
        'REG-$randomNumber'; // Example format: REG-123456

    return registrationNumber;
  }

  void _storeRegistrationNumber() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String registrationNumber = _registrationNumController.text;
    await prefs.setString('registrationNumber', registrationNumber);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _registrationNumController.dispose();
    _firstNameController.dispose();
    _fNameController.dispose();
    _contactNumController.dispose();
    _emergencyContactNumController.dispose();
    _usernameController.dispose();
    _cityNameController.dispose();
    _countryNameController.dispose();
    _CNICNumController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _registrationNumController.text = generateRegistrationNumber();
  }
}
