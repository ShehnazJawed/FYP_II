import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:imperial_inn/utils.dart';
import 'package:share/share.dart';

class DrawerWidget extends StatefulWidget {
  final String userName;
  //final bool isLogin;
  const DrawerWidget({
    super.key,
    required this.userName,
  });

  @override
  State<DrawerWidget> createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  
  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: ListView(
        children: [
          Container(
            height: 200.h,
            child: Padding(
              padding: const EdgeInsets.all(0),
              child: Image.asset(
                'assets/images/logo.jpg',
                fit: BoxFit.fill,
              ),
            ),
          ),
          Container(
            decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10))),
            child: ListView(
              shrinkWrap: true,
              children: [
                ListTile(
                  leading: Icon(
                    Icons.person_3_outlined,
                    color: primaryColor,
                  ),
                  title: Text(
                    widget.userName,
                    style: styleTileTitle,
                  ),
                ),
                ListTile(
                  onTap: () {
                    print('share us btn');
                    Share.share("Download Now \n" +
                        "#imperialIn https://play.google.com/store/apps/details?id=com.example.imperial_inn&hl=en");
                  },
                  leading: Icon(
                    Icons.share_outlined,
                    size: 25,
                    color: primaryColor,
                  ),
                  title: Text('Invite Friends', style: styleTileTitle),
                ),
                ListTile(
                  onTap: _signOut,
                  leading: Icon(
                    Icons.logout_outlined,
                    color: primaryColor,
                  ),
                  title: Text(
                    "Logout Here",
                    style: styleTileTitle,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

//signout function
  Future<void> _signOut() async {
    await _auth.signOut();
  }

  TextStyle styleTileTitle = TextStyle(
      fontSize: 16.sp, color: primaryColor, fontFamily: 'Lato-Regular');
}
