import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

final Color primaryColor = Color(0xFF124076);

void snackBar(String message) {
  Fluttertoast.showToast(
      msg: "$message",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.black54,
      textColor: Colors.white,
      fontSize: 16.0);
}
//097746